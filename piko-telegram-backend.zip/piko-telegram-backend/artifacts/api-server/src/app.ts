import express, { type Express } from "express";
import cors from "cors";
import pinoHttp from "pino-http";
import router from "./routes";
import { logger } from "./lib/logger";

const app: Express = express();

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0],
        };
      },
      res(res) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);
app.use(cors());
app.use(express.json({ limit: "1mb" }));
app.use(express.urlencoded({ extended: true, limit: "1mb" }));

app.use("/api", router);

app.use(
  (
    error: unknown,
    request: express.Request,
    response: express.Response,
    _next: express.NextFunction,
  ): void => {
    if (response.headersSent) {
      response.end();
      return;
    }

    request.log.error(
      {
        errorName: error instanceof Error ? error.name : "unknown",
        errorCode:
          typeof error === "object" && error !== null && "code" in error
            ? String(error.code)
            : undefined,
      },
      "Unhandled API request error",
    );
    response.status(500).json({ error: "Internal server error." });
  },
);

export default app;
