import type { NextFunction, Request, Response } from "express";
import type { DecodedIdToken } from "firebase-admin/auth";
import { Timestamp } from "firebase-admin/firestore";
import { firebaseAuth, firestore } from "../lib/firebase";
import type { UserProfile } from "../lib/models";

export interface AuthenticatedRequest extends Request {
  authUser: DecodedIdToken;
  userProfile: UserProfile;
}

function makeInitialProfile(user: DecodedIdToken): UserProfile {
  const safeUid = user.uid.replace(/[^a-zA-Z0-9_-]/g, "").toLowerCase();
  const now = Timestamp.now();
  return {
    uid: user.uid,
    email: user.email ?? null,
    phoneNumber: user.phone_number ?? null,
    username: `u_${safeUid.slice(0, 28)}`,
    displayName: (user.name ?? "New user").slice(0, 80),
    bio: "",
    profilePhotoUrl: user.picture ?? null,
    isPrivate: false,
    profileCompleted: false,
    isVerified: false,
    accountStatus: "active",
    followersCount: 0,
    followingCount: 0,
    likesCount: 0,
    createdAt: now,
    updatedAt: now,
  };
}

async function loadOrCreateProfile(user: DecodedIdToken): Promise<UserProfile> {
  const profileRef = firestore.collection("users").doc(user.uid);
  const profile = await firestore.runTransaction(async (transaction) => {
    const snapshot = await transaction.get(profileRef);
    if (snapshot.exists) {
      return snapshot.data() as UserProfile;
    }

    const initialProfile = makeInitialProfile(user);
    transaction.create(profileRef, initialProfile);
    return initialProfile;
  });

  return {
    ...profile,
    uid: profile.uid || user.uid,
    username: profile.username || makeInitialProfile(user).username,
    displayName: profile.displayName || "New user",
    bio: profile.bio ?? "",
    isPrivate: profile.isPrivate ?? false,
    profileCompleted: profile.profileCompleted ?? false,
    isVerified: profile.isVerified ?? false,
    accountStatus: profile.accountStatus ?? "active",
    followersCount: profile.followersCount ?? 0,
    followingCount: profile.followingCount ?? 0,
    likesCount: profile.likesCount ?? 0,
  };
}

export async function requireAuth(
  request: Request,
  response: Response,
  next: NextFunction,
): Promise<void> {
  const authorization = request.get("authorization");
  const match = authorization?.match(/^Bearer\s+(\S+)$/i);
  if (!match) {
    response.status(401).json({ error: "A Firebase ID token is required." });
    return;
  }

  let authUser: DecodedIdToken;
  try {
    authUser = await firebaseAuth.verifyIdToken(match[1], true);
  } catch (error) {
    const code =
      typeof error === "object" && error !== null && "code" in error
        ? String(error.code)
        : "";
    if (
      code === "auth/network-request-failed" ||
      code === "auth/internal-error"
    ) {
      response.status(503).json({ error: "Authentication service unavailable." });
      return;
    }
    request.log.warn({ errorCode: code || "invalid-token" }, "Rejected Firebase ID token");
    response.status(401).json({ error: "Firebase ID token is invalid or expired." });
    return;
  }

  try {
    const userProfile = await loadOrCreateProfile(authUser);
    if (userProfile.accountStatus !== "active") {
      response.status(403).json({ error: "This account is not active." });
      return;
    }

    const authenticatedRequest = request as AuthenticatedRequest;
    authenticatedRequest.authUser = authUser;
    authenticatedRequest.userProfile = userProfile;
    next();
  } catch (error) {
    next(error);
  }
}