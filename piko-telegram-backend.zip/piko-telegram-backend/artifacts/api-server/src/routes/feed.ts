import { Timestamp } from "firebase-admin/firestore";
import { Router, type IRouter } from "express";
import {
  GetForYouFeedQueryParams,
  GetForYouFeedResponse,
} from "@workspace/api-zod";
import { requireAuth, type AuthenticatedRequest } from "../middlewares/auth";
import { firestore } from "../lib/firebase";
import {
  toIsoString,
  videoDto,
  type UserProfile,
  type VideoRecord,
} from "../lib/models";
import {
  rankRecommendations,
  type RecommendationCandidate,
  type RecommendationSignalInput,
} from "../lib/recommendation";
import type { RecommendationSignalProfile } from "../lib/signals";

const router: IRouter = Router();
router.use(requireAuth);

function authenticated(request: Parameters<typeof requireAuth>[0]) {
  return request as AuthenticatedRequest;
}

function timestampMillis(value: unknown): number {
  if (value instanceof Timestamp) return value.toMillis();
  if (value instanceof Date) return value.getTime();
  if (typeof value === "string") {
    const parsed = new Date(value).getTime();
    return Number.isNaN(parsed) ? 0 : parsed;
  }
  return 0;
}

router.get("/feed/for-you", async (request, response): Promise<void> => {
  const parsed = GetForYouFeedQueryParams.safeParse(request.query);
  if (!parsed.success) {
    response.status(400).json({ error: parsed.error.message });
    return;
  }

  const { authUser } = authenticated(request);
  const userRef = firestore.collection("users").doc(authUser.uid);
  const signalRef = userRef.collection("recommendationSignals").doc("profile");
  const historyRef = userRef.collection("recommendationHistory");
  const [videoSnapshot, signalSnapshot, historySnapshot] = await Promise.all([
    firestore.collection("videos").orderBy("createdAt", "desc").limit(500).get(),
    signalRef.get(),
    historyRef.orderBy("lastServedAt", "desc").limit(300).get(),
  ]);

  const rawVideos = videoSnapshot.docs
    .map((document) => ({
      id: document.id,
      video: document.data() as VideoRecord,
    }))
    .filter(
      ({ id, video }) =>
        video.status === "ready" &&
        video.visibility === "public" &&
        video.ownerId !== authUser.uid &&
        Boolean(id),
    );

  const ownerIds = [...new Set(rawVideos.map(({ video }) => video.ownerId))];
  const ownerRefs = ownerIds.map((uid) => firestore.collection("users").doc(uid));
  const ownerSnapshots =
    ownerRefs.length > 0 ? await firestore.getAll(...ownerRefs) : [];
  const ownerProfiles = new Map<string, UserProfile>(
    ownerSnapshots
      .filter((snapshot) => snapshot.exists)
      .map((snapshot) => [
        snapshot.id,
        snapshot.data() as UserProfile,
      ]),
  );

  const available = rawVideos.filter(({ video }) => {
    const owner = ownerProfiles.get(video.ownerId);
    return (
      owner !== undefined &&
      (owner.accountStatus ?? "active") === "active" &&
      owner.isPrivate !== true
    );
  });

  const candidates: RecommendationCandidate[] = available.map(
    ({ id, video }) => ({
      id,
      ownerId: video.ownerId,
      tags: Array.isArray(video.tags) ? video.tags : [],
      createdAtMs: timestampMillis(video.createdAt),
      likeCount: video.likeCount ?? 0,
      commentCount: video.commentCount ?? 0,
      shareCount: video.shareCount ?? 0,
      saveCount: video.saveCount ?? 0,
      viewCount: video.viewCount ?? 0,
      averageCompletionPercent: video.averageCompletionPercent ?? 0,
    }),
  );

  const nowMs = Date.now();
  const servedCutoff = nowMs - 14 * 24 * 60 * 60 * 1000;
  const recentlyServedIds = new Set(
    historySnapshot.docs
      .filter(
        (document) =>
          timestampMillis(document.get("lastServedAt")) >= servedCutoff,
      )
      .map((document) => document.id),
  );
  const signalDocument =
    signalSnapshot.data() as RecommendationSignalProfile | undefined;
  const signals: RecommendationSignalInput = {
    topicWeights: signalDocument?.topicWeights ?? {},
    creatorWeights: signalDocument?.creatorWeights ?? {},
    negativeVideoIds: signalDocument?.negativeVideoIds ?? {},
    interactionCount: signalDocument?.interactionCount ?? 0,
  };

  const ranked = rankRecommendations(
    candidates,
    signals,
    recentlyServedIds,
    parsed.data.limit,
    nowMs,
  );
  const videosById = new Map(
    available.map(({ id, video }) => [id, video]),
  );
  const items = ranked.map(({ candidate, reason, scores }) => {
    const video = videosById.get(candidate.id);
    if (!video) throw new Error("Ranked video disappeared from the candidate set.");
    return {
      video: videoDto(candidate.id, video),
      reason,
      scores,
    };
  });

  if (items.length > 0) {
    const batch = firestore.batch();
    const servedAt = Timestamp.fromMillis(nowMs);
    for (const item of items) {
      batch.set(
        historyRef.doc(item.video.id),
        { videoId: item.video.id, lastServedAt: servedAt },
        { merge: true },
      );
    }
    await batch.commit();
  }

  const strategy =
    items.length === 0
      ? "trending_fallback"
      : signals.interactionCount < 3
        ? "cold_start"
        : "hybrid_personalized";

  response.json(
    GetForYouFeedResponse.parse({
      strategy,
      items,
    }),
  );
});

export default router;