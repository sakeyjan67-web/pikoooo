import { randomUUID } from "node:crypto";
import { FieldValue, Timestamp } from "firebase-admin/firestore";
import { Router, type IRouter } from "express";
import {
  CreateVideoCommentBody,
  CreateVideoCommentParams,
  CreateVideoCommentResponse,
  LikeVideoParams,
  LikeVideoResponse,
  ListSavedVideosResponse,
  ListVideoCommentsParams,
  ListVideoCommentsResponse,
  RecordVideoEventBody,
  RecordVideoEventParams,
  RecordVideoEventResponse,
  SaveVideoParams,
  SaveVideoResponse,
  UnsaveVideoParams,
  UnsaveVideoResponse,
  UnlikeVideoParams,
  UnlikeVideoResponse,
} from "@workspace/api-zod";
import { requireAuth, type AuthenticatedRequest } from "../middlewares/auth";
import { firestore } from "../lib/firebase";
import {
  toIsoString,
  videoDto,
  type VideoRecord,
} from "../lib/models";
import { applySignalInTransaction, type SignalKind } from "../lib/signals";
import { findAccessibleVideo } from "../lib/video-access";

const router: IRouter = Router();
router.use(requireAuth);

class InteractionTargetNotFoundError extends Error {}

function authenticated(request: Parameters<typeof requireAuth>[0]) {
  return request as AuthenticatedRequest;
}

async function requireVisibleVideo(
  uid: string,
  videoId: string,
  response: Parameters<typeof requireAuth>[1],
) {
  const accessible = await findAccessibleVideo(uid, videoId);
  if (!accessible) {
    response.status(404).json({ error: "Video not found." });
    return null;
  }
  return accessible;
}

function commentDto(
  id: string,
  videoId: string,
  data: {
    uid: string;
    username: string;
    displayName: string;
    text: string;
    createdAt: unknown;
  },
) {
  return {
    id,
    videoId,
    uid: data.uid,
    username: data.username,
    displayName: data.displayName,
    text: data.text,
    createdAt: toIsoString(data.createdAt),
  };
}

router.post(
  "/videos/:videoId/events",
  async (request, response): Promise<void> => {
    const params = RecordVideoEventParams.safeParse(request.params);
    if (!params.success) {
      response.status(400).json({ error: params.error.message });
      return;
    }
    const parsed = RecordVideoEventBody.safeParse(request.body);
    if (!parsed.success) {
      response.status(400).json({ error: parsed.error.message });
      return;
    }

    const { authUser } = authenticated(request);
    const visible = await requireVisibleVideo(
      authUser.uid,
      params.data.videoId,
      response,
    );
    if (!visible) return;

    const videoId = params.data.videoId;
    const eventId = `video_${videoId}_${parsed.data.eventId}`;
    const now = Timestamp.now();
    const kind: SignalKind = parsed.data.eventType;
    let completionPercent = parsed.data.completionPercent ?? 0;
    if (parsed.data.watchDurationMs !== undefined && visible.video.durationMs > 0) {
      completionPercent = Math.min(
        100,
        (parsed.data.watchDurationMs / visible.video.durationMs) * 100,
      );
    }
    completionPercent = Math.max(0, Math.min(100, completionPercent));

    try {
      await firestore.runTransaction(async (transaction) => {
        const videoSnapshot = await transaction.get(visible.ref);
        if (!videoSnapshot.exists) throw new InteractionTargetNotFoundError();
        const video = videoSnapshot.data() as VideoRecord;
        const applied = await applySignalInTransaction(
          transaction,
          authUser.uid,
          eventId,
          {
            kind,
            videoId,
            ownerId: video.ownerId,
            tags: video.tags ?? [],
            completionPercent,
            occurredAtMs: now.toMillis(),
          },
        );
        if (!applied) return;

        if (kind === "watch") {
          const previousCount = video.viewCount ?? 0;
          const nextCount = previousCount + 1;
          const previousAverage = video.averageCompletionPercent ?? 0;
          const nextAverage =
            (previousAverage * previousCount + completionPercent) / nextCount;
          transaction.update(visible.ref, {
            viewCount: FieldValue.increment(1),
            averageCompletionPercent: nextAverage,
            updatedAt: now,
          });
        } else if (kind === "share") {
          transaction.update(visible.ref, {
            shareCount: FieldValue.increment(1),
            updatedAt: now,
          });
        }
      });
    } catch (error) {
      if (error instanceof InteractionTargetNotFoundError) {
        response.status(404).json({ error: "Video not found." });
        return;
      }
      throw error;
    }

    response.json(RecordVideoEventResponse.parse({ success: true }));
  },
);

router.put(
  "/videos/:videoId/like",
  async (request, response): Promise<void> => {
    const params = LikeVideoParams.safeParse(request.params);
    if (!params.success) {
      response.status(400).json({ error: params.error.message });
      return;
    }
    const { authUser } = authenticated(request);
    const visible = await requireVisibleVideo(
      authUser.uid,
      params.data.videoId,
      response,
    );
    if (!visible) return;
    if (visible.video.ownerId === authUser.uid) {
      response.status(400).json({ error: "You cannot like your own video." });
      return;
    }

    const likeRef = visible.ref.collection("likes").doc(authUser.uid);
    const ownerRef = firestore.collection("users").doc(visible.video.ownerId);
    const eventId = `like_${randomUUID()}`;
    const now = Timestamp.now();
    try {
      await firestore.runTransaction(async (transaction) => {
        const [videoSnapshot, likeSnapshot, ownerSnapshot] = await Promise.all([
          transaction.get(visible.ref),
          transaction.get(likeRef),
          transaction.get(ownerRef),
        ]);
        if (!videoSnapshot.exists || !ownerSnapshot.exists) {
          throw new InteractionTargetNotFoundError();
        }
        if (likeSnapshot.exists) return;

        const video = videoSnapshot.data() as VideoRecord;
        await applySignalInTransaction(transaction, authUser.uid, eventId, {
          kind: "like",
          videoId: params.data.videoId,
          ownerId: video.ownerId,
          tags: video.tags ?? [],
          occurredAtMs: now.toMillis(),
        });
        transaction.create(likeRef, { uid: authUser.uid, createdAt: now });
        transaction.update(visible.ref, {
          likeCount: FieldValue.increment(1),
          updatedAt: now,
        });
        transaction.update(ownerRef, {
          likesCount: FieldValue.increment(1),
          updatedAt: now,
        });
      });
    } catch (error) {
      if (error instanceof InteractionTargetNotFoundError) {
        response.status(404).json({ error: "Video not found." });
        return;
      }
      throw error;
    }
    response.json(LikeVideoResponse.parse({ success: true }));
  },
);

router.delete(
  "/videos/:videoId/like",
  async (request, response): Promise<void> => {
    const params = UnlikeVideoParams.safeParse(request.params);
    if (!params.success) {
      response.status(400).json({ error: params.error.message });
      return;
    }
    const { authUser } = authenticated(request);
    const visible = await requireVisibleVideo(
      authUser.uid,
      params.data.videoId,
      response,
    );
    if (!visible) return;
    if (visible.video.ownerId === authUser.uid) {
      response.status(400).json({ error: "You cannot unlike your own video." });
      return;
    }

    const likeRef = visible.ref.collection("likes").doc(authUser.uid);
    const ownerRef = firestore.collection("users").doc(visible.video.ownerId);
    const eventId = `unlike_${randomUUID()}`;
    const now = Timestamp.now();
    try {
      await firestore.runTransaction(async (transaction) => {
        const [videoSnapshot, likeSnapshot, ownerSnapshot] = await Promise.all([
          transaction.get(visible.ref),
          transaction.get(likeRef),
          transaction.get(ownerRef),
        ]);
        if (!videoSnapshot.exists || !ownerSnapshot.exists) {
          throw new InteractionTargetNotFoundError();
        }
        if (!likeSnapshot.exists) return;

        const video = videoSnapshot.data() as VideoRecord;
        await applySignalInTransaction(transaction, authUser.uid, eventId, {
          kind: "unlike",
          videoId: params.data.videoId,
          ownerId: video.ownerId,
          tags: video.tags ?? [],
          occurredAtMs: now.toMillis(),
        });
        transaction.delete(likeRef);
        transaction.update(visible.ref, {
          likeCount: FieldValue.increment(-1),
          updatedAt: now,
        });
        transaction.update(ownerRef, {
          likesCount: FieldValue.increment(-1),
          updatedAt: now,
        });
      });
    } catch (error) {
      if (error instanceof InteractionTargetNotFoundError) {
        response.status(404).json({ error: "Video not found." });
        return;
      }
      throw error;
    }
    response.json(UnlikeVideoResponse.parse({ success: true }));
  },
);

router.put(
  "/videos/:videoId/save",
  async (request, response): Promise<void> => {
    const params = SaveVideoParams.safeParse(request.params);
    if (!params.success) {
      response.status(400).json({ error: params.error.message });
      return;
    }
    const { authUser } = authenticated(request);
    const visible = await requireVisibleVideo(
      authUser.uid,
      params.data.videoId,
      response,
    );
    if (!visible) return;

    const savedRef = firestore
      .collection("users")
      .doc(authUser.uid)
      .collection("savedVideos")
      .doc(params.data.videoId);
    const eventId = `save_${randomUUID()}`;
    const now = Timestamp.now();
    try {
      await firestore.runTransaction(async (transaction) => {
        const [videoSnapshot, savedSnapshot] = await Promise.all([
          transaction.get(visible.ref),
          transaction.get(savedRef),
        ]);
        if (!videoSnapshot.exists) throw new InteractionTargetNotFoundError();
        if (savedSnapshot.exists) return;

        const video = videoSnapshot.data() as VideoRecord;
        await applySignalInTransaction(transaction, authUser.uid, eventId, {
          kind: "save",
          videoId: params.data.videoId,
          ownerId: video.ownerId,
          tags: video.tags ?? [],
          occurredAtMs: now.toMillis(),
        });
        transaction.create(savedRef, {
          videoId: params.data.videoId,
          savedAt: now,
        });
        transaction.update(visible.ref, {
          saveCount: FieldValue.increment(1),
          updatedAt: now,
        });
      });
    } catch (error) {
      if (error instanceof InteractionTargetNotFoundError) {
        response.status(404).json({ error: "Video not found." });
        return;
      }
      throw error;
    }
    response.json(SaveVideoResponse.parse({ success: true }));
  },
);

router.delete(
  "/videos/:videoId/save",
  async (request, response): Promise<void> => {
    const params = UnsaveVideoParams.safeParse(request.params);
    if (!params.success) {
      response.status(400).json({ error: params.error.message });
      return;
    }
    const { authUser } = authenticated(request);
    const visible = await requireVisibleVideo(
      authUser.uid,
      params.data.videoId,
      response,
    );
    if (!visible) return;

    const savedRef = firestore
      .collection("users")
      .doc(authUser.uid)
      .collection("savedVideos")
      .doc(params.data.videoId);
    const eventId = `unsave_${randomUUID()}`;
    const now = Timestamp.now();
    try {
      await firestore.runTransaction(async (transaction) => {
        const [videoSnapshot, savedSnapshot] = await Promise.all([
          transaction.get(visible.ref),
          transaction.get(savedRef),
        ]);
        if (!videoSnapshot.exists) throw new InteractionTargetNotFoundError();
        if (!savedSnapshot.exists) return;

        const video = videoSnapshot.data() as VideoRecord;
        await applySignalInTransaction(transaction, authUser.uid, eventId, {
          kind: "unsave",
          videoId: params.data.videoId,
          ownerId: video.ownerId,
          tags: video.tags ?? [],
          occurredAtMs: now.toMillis(),
        });
        transaction.delete(savedRef);
        transaction.update(visible.ref, {
          saveCount: FieldValue.increment(-1),
          updatedAt: now,
        });
      });
    } catch (error) {
      if (error instanceof InteractionTargetNotFoundError) {
        response.status(404).json({ error: "Video not found." });
        return;
      }
      throw error;
    }
    response.json(UnsaveVideoResponse.parse({ success: true }));
  },
);

router.get("/me/saved-videos", async (request, response): Promise<void> => {
  const { authUser } = authenticated(request);
  const savedSnapshot = await firestore
    .collection("users")
    .doc(authUser.uid)
    .collection("savedVideos")
    .orderBy("savedAt", "desc")
    .limit(100)
    .get();
  const videos = await Promise.all(
    savedSnapshot.docs.map(async (document) => {
      const accessible = await findAccessibleVideo(authUser.uid, document.id);
      if (!accessible) return null;
      return videoDto(document.id, accessible.video);
    }),
  );
  response.json(
    ListSavedVideosResponse.parse(videos.filter((video) => video !== null)),
  );
});

router.get(
  "/videos/:videoId/comments",
  async (request, response): Promise<void> => {
    const params = ListVideoCommentsParams.safeParse(request.params);
    if (!params.success) {
      response.status(400).json({ error: params.error.message });
      return;
    }
    const { authUser } = authenticated(request);
    const visible = await requireVisibleVideo(
      authUser.uid,
      params.data.videoId,
      response,
    );
    if (!visible) return;

    const commentsSnapshot = await visible.ref
      .collection("comments")
      .orderBy("createdAt", "desc")
      .limit(30)
      .get();
    const comments = commentsSnapshot.docs.map((document) =>
      commentDto(document.id, params.data.videoId, document.data() as {
        uid: string;
        username: string;
        displayName: string;
        text: string;
        createdAt: unknown;
      }),
    );
    response.json(ListVideoCommentsResponse.parse(comments));
  },
);

router.post(
  "/videos/:videoId/comments",
  async (request, response): Promise<void> => {
    const params = CreateVideoCommentParams.safeParse(request.params);
    if (!params.success) {
      response.status(400).json({ error: params.error.message });
      return;
    }
    const parsed = CreateVideoCommentBody.safeParse(request.body);
    if (!parsed.success) {
      response.status(400).json({ error: parsed.error.message });
      return;
    }
    const { authUser, userProfile } = authenticated(request);
    const visible = await requireVisibleVideo(
      authUser.uid,
      params.data.videoId,
      response,
    );
    if (!visible) return;

    const commentRef = visible.ref.collection("comments").doc();
    const now = Timestamp.now();
    const comment = {
      uid: authUser.uid,
      username: userProfile.username,
      displayName: userProfile.displayName,
      text: parsed.data.text,
      createdAt: now,
    };
    try {
      await firestore.runTransaction(async (transaction) => {
        const videoSnapshot = await transaction.get(visible.ref);
        if (!videoSnapshot.exists) throw new InteractionTargetNotFoundError();
        const video = videoSnapshot.data() as VideoRecord;
        await applySignalInTransaction(
          transaction,
          authUser.uid,
          `comment_${commentRef.id}`,
          {
            kind: "comment",
            videoId: params.data.videoId,
            ownerId: video.ownerId,
            tags: video.tags ?? [],
            occurredAtMs: now.toMillis(),
          },
        );
        transaction.create(commentRef, comment);
        transaction.update(visible.ref, {
          commentCount: FieldValue.increment(1),
          updatedAt: now,
        });
      });
    } catch (error) {
      if (error instanceof InteractionTargetNotFoundError) {
        response.status(404).json({ error: "Video not found." });
        return;
      }
      throw error;
    }

    response
      .status(201)
      .json(
        CreateVideoCommentResponse.parse(
          commentDto(commentRef.id, params.data.videoId, comment),
        ),
      );
  },
);

export default router;