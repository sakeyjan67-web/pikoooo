import { randomUUID } from "node:crypto";
import { open, unlink } from "node:fs/promises";
import { tmpdir } from "node:os";
import { Readable } from "node:stream";
import type { ReadableStream as NodeReadableStream } from "node:stream/web";
import { pipeline } from "node:stream/promises";
import { FieldValue, Timestamp } from "firebase-admin/firestore";
import express, { Router, type IRouter } from "express";
import multer from "multer";
import {
  GetVideoParams,
  GetVideoResponse,
  StreamVideoHeader,
  StreamVideoParams,
  UploadVideoBody,
  UploadVideoResponse,
} from "@workspace/api-zod";
import { requireAuth, type AuthenticatedRequest } from "../middlewares/auth";
import { firestore } from "../lib/firebase";
import { isSafeDocumentId, videoDto, type VideoRecord } from "../lib/models";
import {
  deleteTelegramMessage,
  openTelegramVideoStream,
  TelegramStorageError,
  uploadVideoToTelegram,
} from "../lib/telegram";
import { findAccessibleVideo } from "../lib/video-access";

const router: IRouter = Router();
const MAX_UPLOAD_BYTES = 20 * 1024 * 1024;
const upload = multer({
  storage: multer.diskStorage({
    destination: tmpdir(),
    filename: (_request, _file, callback) => {
      callback(null, `${randomUUID()}.mp4`);
    },
  }),
  limits: {
    fileSize: MAX_UPLOAD_BYTES,
    files: 1,
    fields: 4,
    fieldSize: 8192,
  },
  fileFilter: (_request, file, callback) => {
    if (
      file.mimetype !== "video/mp4" &&
      file.mimetype !== "application/octet-stream"
    ) {
      callback(new Error("Only MP4 video uploads are supported."));
      return;
    }
    callback(null, true);
  },
});

router.use(requireAuth);

function authenticated(request: express.Request) {
  return request as AuthenticatedRequest;
}

function uploadMiddleware(
  request: express.Request,
  response: express.Response,
  next: express.NextFunction,
): void {
  upload.single("video")(request, response, (error: unknown) => {
    if (!error) {
      next();
      return;
    }
    if (error instanceof multer.MulterError && error.code === "LIMIT_FILE_SIZE") {
      response.status(413).json({ error: "Video exceeds the 20 MiB upload limit." });
      return;
    }
    const message =
      error instanceof Error ? error.message : "Video upload was rejected.";
    response.status(400).json({ error: message });
  });
}

async function hasMp4FileTypeBox(filePath: string): Promise<boolean> {
  const handle = await open(filePath, "r");
  try {
    const header = Buffer.alloc(12);
    const { bytesRead } = await handle.read(header, 0, header.length, 0);
    return bytesRead === header.length && header.toString("ascii", 4, 8) === "ftyp";
  } finally {
    await handle.close();
  }
}

function parseTags(value: string | undefined): string[] {
  if (!value) return [];
  return [
    ...new Set(
      value
        .split(/[,\s]+/)
        .map((tag) => tag.replace(/^#/, "").toLowerCase())
        .map((tag) => tag.replace(/[^a-z0-9_-]/g, ""))
        .filter((tag) => tag.length > 0)
        .map((tag) => tag.slice(0, 24)),
    ),
  ].slice(0, 12);
}

router.post("/videos", uploadMiddleware, async (request, response): Promise<void> => {
  const { authUser, userProfile } = authenticated(request);
  const bodySchema = UploadVideoBody.omit({ video: true });
  const parsed = bodySchema.safeParse(request.body);
  if (!parsed.success) {
    response.status(400).json({ error: parsed.error.message });
    if (request.file?.path) {
      await unlink(request.file.path).catch(() => undefined);
    }
    return;
  }

  const file = request.file;
  if (!file) {
    response.status(400).json({ error: "An MP4 video file is required." });
    return;
  }

  let uploaded:
    | Awaited<ReturnType<typeof uploadVideoToTelegram>>
    | undefined;
  try {
    if (!(await hasMp4FileTypeBox(file.path))) {
      response.status(400).json({ error: "The uploaded file is not a valid MP4." });
      return;
    }

    const visibility =
      parsed.data.visibility ?? (userProfile.isPrivate ? "followers" : "public");
    uploaded = await uploadVideoToTelegram({
      path: file.path,
      sizeBytes: file.size,
      durationMs: parsed.data.durationMs,
    });

    const videoRef = firestore.collection("videos").doc();
    const now = Timestamp.now();
    const video: VideoRecord = {
      ownerId: authUser.uid,
      caption: parsed.data.caption ?? "",
      tags: parseTags(parsed.data.tags),
      visibility,
      durationMs: parsed.data.durationMs,
      fileSizeBytes: file.size,
      likeCount: 0,
      commentCount: 0,
      viewCount: 0,
      shareCount: 0,
      saveCount: 0,
      averageCompletionPercent: 0,
      status: "ready",
      telegramFileId: uploaded.fileId,
      telegramFileUniqueId: uploaded.fileUniqueId,
      telegramMessageId: uploaded.messageId,
      createdAt: now,
      updatedAt: now,
    };

    try {
      await videoRef.create(video);
    } catch (error) {
      await deleteTelegramMessage(uploaded.messageId).catch(() => {
        request.log.error(
          { videoId: videoRef.id },
          "Failed to clean up Telegram upload after Firebase write failure",
        );
      });
      throw error;
    }

    response
      .status(201)
      .json(UploadVideoResponse.parse(videoDto(videoRef.id, video)));
  } catch (error) {
    if (error instanceof TelegramStorageError) {
      request.log.warn(
        { errorName: "TelegramStorageError" },
        "Telegram video storage request failed",
      );
      response.status(503).json({ error: error.message });
      return;
    }
    throw error;
  } finally {
    await unlink(file.path).catch((error: unknown) => {
      request.log.warn(
        {
          errorName: error instanceof Error ? error.name : "unknown",
        },
        "Could not remove temporary video upload",
      );
    });
  }
});

router.get("/videos/:videoId", async (request, response): Promise<void> => {
  const params = GetVideoParams.safeParse(request.params);
  if (!params.success) {
    response.status(400).json({ error: params.error.message });
    return;
  }
  if (!isSafeDocumentId(params.data.videoId)) {
    response.status(400).json({ error: "Invalid video ID." });
    return;
  }
  const { authUser } = authenticated(request);
  const result = await findAccessibleVideo(authUser.uid, params.data.videoId);
  if (!result) {
    response.status(404).json({ error: "Video not found." });
    return;
  }
  response.json(
    GetVideoResponse.parse(videoDto(params.data.videoId, result.video)),
  );
});

router.get(
  "/videos/:videoId/stream",
  async (request, response): Promise<void> => {
    const params = StreamVideoParams.safeParse(request.params);
    if (!params.success) {
      response.status(400).json({ error: params.error.message });
      return;
    }
    if (!isSafeDocumentId(params.data.videoId)) {
      response.status(400).json({ error: "Invalid video ID." });
      return;
    }
    const parsedHeader = StreamVideoHeader.safeParse({
      Range: request.get("Range") ?? undefined,
    });
    if (!parsedHeader.success) {
      response.status(400).json({ error: parsedHeader.error.message });
      return;
    }

    const { authUser } = authenticated(request);
    const result = await findAccessibleVideo(authUser.uid, params.data.videoId);
    if (!result) {
      response.status(404).json({ error: "Video not found." });
      return;
    }

    let upstream: Response;
    try {
      upstream = await openTelegramVideoStream(
        result.video.telegramFileId,
        parsedHeader.data.Range,
      );
    } catch (error) {
      if (error instanceof TelegramStorageError) {
        request.log.warn(
          { videoId: params.data.videoId },
          "Could not open Telegram video stream",
        );
        response.status(503).json({ error: "Video storage is temporarily unavailable." });
        return;
      }
      throw error;
    }

    response.status(upstream.status);
    response.setHeader("Content-Type", "video/mp4");
    response.setHeader("Accept-Ranges", upstream.headers.get("accept-ranges") ?? "bytes");
    response.setHeader("Cache-Control", "private, no-store");
    response.setHeader(
      "Content-Disposition",
      `inline; filename="${params.data.videoId}.mp4"`,
    );
    const contentLength = upstream.headers.get("content-length");
    const contentRange = upstream.headers.get("content-range");
    if (contentLength) response.setHeader("Content-Length", contentLength);
    if (contentRange) response.setHeader("Content-Range", contentRange);

    await pipeline(
      Readable.fromWeb(upstream.body as NodeReadableStream),
      response,
    );
  },
);

export default router;