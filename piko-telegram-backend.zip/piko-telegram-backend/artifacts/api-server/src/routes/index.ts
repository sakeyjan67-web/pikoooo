import { Router, type IRouter } from "express";
import feedRouter from "./feed";
import healthRouter from "./health";
import interactionsRouter from "./interactions";
import profilesRouter from "./profiles";
import videosRouter from "./videos";

const router: IRouter = Router();

router.use(healthRouter);
router.use(profilesRouter);
router.use(videosRouter);
router.use(interactionsRouter);
router.use(feedRouter);

export default router;
