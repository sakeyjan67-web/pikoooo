import { FieldValue, Timestamp } from "firebase-admin/firestore";
import { Router, type IRouter } from "express";
import {
  DecideFollowRequestBody,
  DecideFollowRequestParams,
  DecideFollowRequestResponse,
  FollowRequestList,
  FollowResult,
  FollowUserParams,
  FollowUserResponse,
  GetMyProfileResponse,
  GetUserProfileParams,
  GetUserProfileResponse,
  ListFollowRequestsResponse,
  UnfollowUserParams,
  UnfollowUserResponse,
  UpdateMyProfileBody,
  UpdateMyProfileResponse,
} from "@workspace/api-zod";
import { requireAuth, type AuthenticatedRequest } from "../middlewares/auth";
import { firestore } from "../lib/firebase";
import {
  ownProfileDto,
  publicProfileDto,
  isSafeDocumentId,
  toIsoString,
  type UserProfile,
} from "../lib/models";
import { applySignalInTransaction } from "../lib/signals";

const router: IRouter = Router();
router.use(requireAuth);

class UsernameTakenError extends Error {}
class FollowTargetNotFoundError extends Error {}
class FollowRequestNotFoundError extends Error {}

function authenticated(request: Parameters<typeof requireAuth>[0]) {
  return request as AuthenticatedRequest;
}

router.get("/me", (request, response): void => {
  const profile = authenticated(request).userProfile;
  response.json(GetMyProfileResponse.parse(ownProfileDto(profile)));
});

router.patch("/me", async (request, response): Promise<void> => {
  const parsed = UpdateMyProfileBody.safeParse(request.body);
  if (!parsed.success) {
    response.status(400).json({ error: parsed.error.message });
    return;
  }
  if (Object.keys(parsed.data).length === 0) {
    response.status(400).json({ error: "At least one profile field is required." });
    return;
  }

  const { authUser, userProfile } = authenticated(request);
  const profileRef = firestore.collection("users").doc(authUser.uid);
  const updates: Record<string, unknown> = { ...parsed.data };
  if (typeof updates.username === "string") {
    updates.username = updates.username.toLowerCase();
  }
  const updatedAt = Timestamp.now();
  updates.updatedAt = updatedAt;

  const safeUid = authUser.uid.replace(/[^a-zA-Z0-9_-]/g, "").toLowerCase();
  const defaultUsername = `u_${safeUid.slice(0, 28)}`;
  const effectiveUsername = updates.username ?? userProfile.username;
  const effectiveDisplayName = updates.displayName ?? userProfile.displayName;
  if (
    typeof effectiveUsername === "string" &&
    effectiveUsername !== defaultUsername &&
    typeof effectiveDisplayName === "string" &&
    effectiveDisplayName.trim().length > 0 &&
    effectiveDisplayName !== "New user"
  ) {
    updates.profileCompleted = true;
  }

  try {
    await firestore.runTransaction(async (transaction) => {
      const profileSnapshot = await transaction.get(profileRef);
      if (!profileSnapshot.exists) {
        throw new Error("Signed-in user profile is missing.");
      }

      if (typeof updates.username === "string") {
        const matches = await transaction.get(
          firestore
            .collection("users")
            .where("username", "==", updates.username)
            .limit(2),
        );
        if (matches.docs.some((document) => document.id !== authUser.uid)) {
          throw new UsernameTakenError();
        }
      }

      transaction.update(profileRef, updates);
    });
  } catch (error) {
    if (error instanceof UsernameTakenError) {
      response.status(409).json({ error: "That username is already in use." });
      return;
    }
    throw error;
  }

  const updatedProfile = {
    ...userProfile,
    ...updates,
    updatedAt,
  } as UserProfile;
  response.json(
    UpdateMyProfileResponse.parse(ownProfileDto(updatedProfile)),
  );
});

router.get("/users/:uid", async (request, response): Promise<void> => {
  const params = GetUserProfileParams.safeParse(request.params);
  if (!params.success) {
    response.status(400).json({ error: params.error.message });
    return;
  }
  if (!isSafeDocumentId(params.data.uid)) {
    response.status(400).json({ error: "Invalid user ID." });
    return;
  }

  const snapshot = await firestore.collection("users").doc(params.data.uid).get();
  if (!snapshot.exists) {
    response.status(404).json({ error: "Profile not found." });
    return;
  }

  const profile = snapshot.data() as UserProfile;
  if ((profile.accountStatus ?? "active") !== "active") {
    response.status(404).json({ error: "Profile not found." });
    return;
  }
  response.json(
    GetUserProfileResponse.parse(
      publicProfileDto({ ...profile, uid: profile.uid || snapshot.id }),
    ),
  );
});

router.put("/users/:uid/follow", async (request, response): Promise<void> => {
  const params = FollowUserParams.safeParse(request.params);
  if (!params.success) {
    response.status(400).json({ error: params.error.message });
    return;
  }

  const { authUser } = authenticated(request);
  const targetUid = params.data.uid;
  if (!isSafeDocumentId(targetUid)) {
    response.status(400).json({ error: "Invalid user ID." });
    return;
  }
  if (targetUid === authUser.uid) {
    response.status(400).json({ error: "You cannot follow your own account." });
    return;
  }

  const db = firestore;
  const currentProfileRef = db.collection("users").doc(authUser.uid);
  const targetProfileRef = db.collection("users").doc(targetUid);
  const followingRef = currentProfileRef.collection("following").doc(targetUid);
  const followerRef = targetProfileRef.collection("followers").doc(authUser.uid);
  const requestRef = targetProfileRef
    .collection("followRequests")
    .doc(authUser.uid);
  const eventId = `follow_${targetUid}_${crypto.randomUUID()}`;

  try {
    const result = await db.runTransaction(async (transaction) => {
      const [
        targetSnapshot,
        followingSnapshot,
        followerSnapshot,
        requestSnapshot,
      ] = await Promise.all([
        transaction.get(targetProfileRef),
        transaction.get(followingRef),
        transaction.get(followerRef),
        transaction.get(requestRef),
      ]);

      if (!targetSnapshot.exists) throw new FollowTargetNotFoundError();
      const targetProfile = targetSnapshot.data() as UserProfile;
      if ((targetProfile.accountStatus ?? "active") !== "active") {
        throw new FollowTargetNotFoundError();
      }

      if (followingSnapshot.exists) {
        return {
          success: true,
          following: true,
          requestPending: false,
        };
      }

      if (targetProfile.isPrivate) {
        if (!requestSnapshot.exists) {
          transaction.create(requestRef, {
            uid: authUser.uid,
            requestedAt: Timestamp.now(),
          });
        }
        return {
          success: true,
          following: false,
          requestPending: true,
        };
      }

      const now = Timestamp.now();
      const signalApplied = await applySignalInTransaction(
        transaction,
        authUser.uid,
        eventId,
        {
          kind: "follow",
          ownerId: targetUid,
          occurredAtMs: now.toMillis(),
        },
      );
      transaction.create(followingRef, { uid: targetUid, createdAt: now });
      if (!followerSnapshot.exists) {
        transaction.create(followerRef, { uid: authUser.uid, createdAt: now });
        transaction.update(targetProfileRef, {
          followersCount: FieldValue.increment(1),
          updatedAt: now,
        });
      }
      transaction.update(currentProfileRef, {
        followingCount: FieldValue.increment(1),
        updatedAt: now,
      });

      return {
        success: true,
        following: true,
        requestPending: false,
        signalApplied,
      };
    });

    response.json(FollowUserResponse.parse(result));
  } catch (error) {
    if (error instanceof FollowTargetNotFoundError) {
      response.status(404).json({ error: "Account not found." });
      return;
    }
    throw error;
  }
});

router.delete("/users/:uid/follow", async (request, response): Promise<void> => {
  const params = UnfollowUserParams.safeParse(request.params);
  if (!params.success) {
    response.status(400).json({ error: params.error.message });
    return;
  }

  const { authUser } = authenticated(request);
  const targetUid = params.data.uid;
  if (!isSafeDocumentId(targetUid)) {
    response.status(400).json({ error: "Invalid user ID." });
    return;
  }
  if (targetUid === authUser.uid) {
    response.status(400).json({ error: "You cannot unfollow your own account." });
    return;
  }

  const currentProfileRef = firestore.collection("users").doc(authUser.uid);
  const targetProfileRef = firestore.collection("users").doc(targetUid);
  const followingRef = currentProfileRef.collection("following").doc(targetUid);
  const followerRef = targetProfileRef.collection("followers").doc(authUser.uid);
  const requestRef = targetProfileRef
    .collection("followRequests")
    .doc(authUser.uid);
  const eventId = `unfollow_${targetUid}_${crypto.randomUUID()}`;
  const now = Timestamp.now();

  const result = await firestore.runTransaction(async (transaction) => {
    const [followingSnapshot, followerSnapshot, requestSnapshot, targetSnapshot] =
      await Promise.all([
        transaction.get(followingRef),
        transaction.get(followerRef),
        transaction.get(requestRef),
        transaction.get(targetProfileRef),
      ]);

    let following = followingSnapshot.exists;
    let requestPending = requestSnapshot.exists;
    if (followingSnapshot.exists) {
      await applySignalInTransaction(transaction, authUser.uid, eventId, {
        kind: "unfollow",
        ownerId: targetUid,
        occurredAtMs: now.toMillis(),
      });
      transaction.delete(followingRef);
      if (followerSnapshot.exists) {
        transaction.delete(followerRef);
      }
      transaction.update(currentProfileRef, {
        followingCount: FieldValue.increment(-1),
        updatedAt: now,
      });
      if (followerSnapshot.exists && targetSnapshot.exists) {
        transaction.update(targetProfileRef, {
          followersCount: FieldValue.increment(-1),
          updatedAt: now,
        });
      }
      following = false;
    }
    if (requestSnapshot.exists) {
      transaction.delete(requestRef);
      requestPending = false;
    }

    return {
      success: true,
      following,
      requestPending,
    };
  });
  response.json(UnfollowUserResponse.parse(result));
});

router.get("/me/follow-requests", async (request, response): Promise<void> => {
  const { authUser } = authenticated(request);
  const requestSnapshot = await firestore
    .collection("users")
    .doc(authUser.uid)
    .collection("followRequests")
    .orderBy("requestedAt", "desc")
    .limit(100)
    .get();

  const requesterRefs = requestSnapshot.docs.map((document) =>
    firestore.collection("users").doc(document.id),
  );
  const requesterSnapshots =
    requesterRefs.length > 0 ? await firestore.getAll(...requesterRefs) : [];
  const profiles = new Map(
    requesterSnapshots
      .filter((snapshot) => snapshot.exists)
      .map((snapshot) => [
        snapshot.id,
        snapshot.data() as UserProfile,
      ]),
  );

  const requests = requestSnapshot.docs.flatMap((document) => {
    const profile = profiles.get(document.id);
    if (!profile) return [];
    return [
      {
        uid: profile.uid || document.id,
        username: profile.username,
        displayName: profile.displayName,
        profilePhotoUrl: profile.profilePhotoUrl ?? null,
        requestedAt: toIsoString(document.get("requestedAt")),
      },
    ];
  });

  response.json(ListFollowRequestsResponse.parse(requests));
});

router.put(
  "/me/follow-requests/:requesterUid",
  async (request, response): Promise<void> => {
    const params = DecideFollowRequestParams.safeParse(request.params);
    if (!params.success) {
      response.status(400).json({ error: params.error.message });
      return;
    }
    const parsed = DecideFollowRequestBody.safeParse(request.body);
    if (!parsed.success) {
      response.status(400).json({ error: parsed.error.message });
      return;
    }

    const { authUser } = authenticated(request);
    const requesterUid = params.data.requesterUid;
    if (!isSafeDocumentId(requesterUid)) {
      response.status(400).json({ error: "Invalid user ID." });
      return;
    }
    const ownerRef = firestore.collection("users").doc(authUser.uid);
    const requesterRef = firestore.collection("users").doc(requesterUid);
    const requestRef = ownerRef.collection("followRequests").doc(requesterUid);
    const followingRef = requesterRef.collection("following").doc(authUser.uid);
    const followerRef = ownerRef.collection("followers").doc(requesterUid);
    const eventId = `follow_${authUser.uid}_${crypto.randomUUID()}`;
    const now = Timestamp.now();

    try {
      const result = await firestore.runTransaction(async (transaction) => {
        const [
          requestSnapshot,
          ownerSnapshot,
          requesterSnapshot,
          followingSnapshot,
          followerSnapshot,
        ] = await Promise.all([
          transaction.get(requestRef),
          transaction.get(ownerRef),
          transaction.get(requesterRef),
          transaction.get(followingRef),
          transaction.get(followerRef),
        ]);

        if (!requestSnapshot.exists) throw new FollowRequestNotFoundError();
        if (!ownerSnapshot.exists || !requesterSnapshot.exists) {
          throw new FollowRequestNotFoundError();
        }

        if (parsed.data.action === "reject") {
          transaction.delete(requestRef);
          return { success: true, following: false, requestPending: false };
        }

        if (!followingSnapshot.exists) {
          await applySignalInTransaction(transaction, requesterUid, eventId, {
            kind: "follow",
            ownerId: authUser.uid,
            occurredAtMs: now.toMillis(),
          });
          transaction.create(followingRef, {
            uid: authUser.uid,
            createdAt: now,
          });
          transaction.update(requesterRef, {
            followingCount: FieldValue.increment(1),
            updatedAt: now,
          });
          if (!followerSnapshot.exists) {
            transaction.create(followerRef, {
              uid: requesterUid,
              createdAt: now,
            });
            transaction.update(ownerRef, {
              followersCount: FieldValue.increment(1),
              updatedAt: now,
            });
          }
        }

        transaction.delete(requestRef);
        return { success: true, following: true, requestPending: false };
      });

      response.json(DecideFollowRequestResponse.parse(result));
    } catch (error) {
      if (error instanceof FollowRequestNotFoundError) {
        response.status(404).json({ error: "Follow request not found." });
        return;
      }
      throw error;
    }
  },
);

export default router;