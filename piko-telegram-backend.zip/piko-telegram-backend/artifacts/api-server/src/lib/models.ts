import { Timestamp } from "firebase-admin/firestore";

export type VideoVisibility = "public" | "followers" | "private";

export interface UserProfile {
  uid: string;
  email?: string | null;
  phoneNumber?: string | null;
  username: string;
  displayName: string;
  bio: string;
  profilePhotoUrl?: string | null;
  isPrivate: boolean;
  profileCompleted: boolean;
  isVerified: boolean;
  accountStatus: string;
  followersCount: number;
  followingCount: number;
  likesCount: number;
  createdAt: Timestamp | Date | string;
  updatedAt: Timestamp | Date | string;
}

export interface VideoRecord {
  ownerId: string;
  caption: string;
  tags: string[];
  visibility: VideoVisibility;
  durationMs: number;
  fileSizeBytes: number;
  likeCount: number;
  commentCount: number;
  viewCount: number;
  shareCount: number;
  saveCount: number;
  averageCompletionPercent: number;
  status: "uploading" | "ready" | "failed";
  telegramFileId: string;
  telegramFileUniqueId: string;
  telegramMessageId: number;
  createdAt: Timestamp | Date | string;
  updatedAt: Timestamp | Date | string;
}

export function toIsoString(value: unknown): string {
  if (value instanceof Timestamp) {
    return value.toDate().toISOString();
  }
  if (value instanceof Date) {
    return value.toISOString();
  }
  if (typeof value === "string") {
    const date = new Date(value);
    if (!Number.isNaN(date.getTime())) {
      return date.toISOString();
    }
  }
  throw new Error("A required Firestore timestamp is missing or invalid.");
}

export function isSafeDocumentId(value: string): boolean {
  return value.length > 0 && value.length <= 256 && !value.includes("/");
}

export function ownProfileDto(profile: UserProfile) {
  return {
    uid: profile.uid,
    email: profile.email ?? null,
    phoneNumber: profile.phoneNumber ?? null,
    username: profile.username ?? "",
    displayName: profile.displayName ?? "",
    bio: profile.bio ?? "",
    profilePhotoUrl: profile.profilePhotoUrl ?? null,
    isPrivate: profile.isPrivate,
    profileCompleted: profile.profileCompleted,
    isVerified: profile.isVerified,
    accountStatus: profile.accountStatus,
    followersCount: profile.followersCount ?? 0,
    followingCount: profile.followingCount ?? 0,
    likesCount: profile.likesCount ?? 0,
    createdAt: toIsoString(profile.createdAt),
    updatedAt: toIsoString(profile.updatedAt),
  };
}

export function publicProfileDto(profile: UserProfile) {
  return {
    uid: profile.uid,
    username: profile.username ?? "",
    displayName: profile.displayName ?? "",
    bio: profile.bio ?? "",
    profilePhotoUrl: profile.profilePhotoUrl ?? null,
    isPrivate: profile.isPrivate ?? false,
    isVerified: profile.isVerified ?? false,
    followersCount: profile.followersCount ?? 0,
    followingCount: profile.followingCount ?? 0,
  };
}

export function videoDto(id: string, video: VideoRecord) {
  return {
    id,
    ownerId: video.ownerId,
    caption: video.caption,
    tags: video.tags,
    visibility: video.visibility,
    durationMs: video.durationMs,
    fileSizeBytes: video.fileSizeBytes,
    likeCount: video.likeCount,
    commentCount: video.commentCount,
    viewCount: video.viewCount,
    shareCount: video.shareCount,
    saveCount: video.saveCount,
    averageCompletionPercent: video.averageCompletionPercent,
    createdAt: toIsoString(video.createdAt),
    playbackPath: `/api/videos/${encodeURIComponent(id)}/stream`,
  };
}