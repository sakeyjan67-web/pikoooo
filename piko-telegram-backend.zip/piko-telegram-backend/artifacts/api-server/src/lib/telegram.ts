import axios from "axios";
import FormData from "form-data";
import { createReadStream } from "node:fs";

const TELEGRAM_API = "https://api.telegram.org";
const TELEGRAM_FILE_API = "https://api.telegram.org/file";

interface TelegramResult<T> {
  ok: boolean;
  result?: T;
}

interface TelegramVideoResult {
  message_id: number;
  video?: {
    file_id: string;
    file_unique_id: string;
  };
}

interface TelegramFileResult {
  file_path?: string;
}

export interface StoredTelegramVideo {
  fileId: string;
  fileUniqueId: string;
  messageId: number;
}

export class TelegramStorageError extends Error {
  constructor(message = "Telegram video storage is unavailable.") {
    super(message);
    this.name = "TelegramStorageError";
  }
}

function telegramConfig() {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  const chatId = process.env.TELEGRAM_STORAGE_CHAT_ID;
  if (!token || !chatId) {
    throw new TelegramStorageError("Telegram storage is not configured.");
  }
  return { token, chatId };
}

export async function uploadVideoToTelegram(input: {
  path: string;
  sizeBytes: number;
  durationMs: number;
}): Promise<StoredTelegramVideo> {
  const { token, chatId } = telegramConfig();
  const form = new FormData();
  form.append("chat_id", chatId);
  form.append("supports_streaming", "true");
  form.append("duration", String(Math.max(1, Math.round(input.durationMs / 1000))));
  form.append("video", createReadStream(input.path), {
    filename: "video.mp4",
    contentType: "video/mp4",
    knownLength: input.sizeBytes,
  });

  try {
    const response = await axios.post<TelegramResult<TelegramVideoResult>>(
      `${TELEGRAM_API}/bot${token}/sendVideo`,
      form,
      {
        headers: form.getHeaders(),
        maxBodyLength: 21 * 1024 * 1024,
        maxContentLength: 1024 * 1024,
        timeout: 120_000,
      },
    );
    const video = response.data.result?.video;
    const messageId = response.data.result?.message_id;
    if (!response.data.ok || !video?.file_id || !video.file_unique_id || !messageId) {
      throw new TelegramStorageError();
    }
    return {
      fileId: video.file_id,
      fileUniqueId: video.file_unique_id,
      messageId,
    };
  } catch {
    throw new TelegramStorageError();
  }
}

async function telegramFilePath(fileId: string): Promise<string> {
  const { token } = telegramConfig();
  try {
    const response = await axios.get<TelegramResult<TelegramFileResult>>(
      `${TELEGRAM_API}/bot${token}/getFile`,
      {
        params: { file_id: fileId },
        timeout: 20_000,
      },
    );
    const filePath = response.data.result?.file_path;
    if (!response.data.ok || !filePath) {
      throw new TelegramStorageError();
    }
    return filePath;
  } catch {
    throw new TelegramStorageError();
  }
}

export async function openTelegramVideoStream(
  fileId: string,
  rangeHeader?: string,
): Promise<Response> {
  const { token } = telegramConfig();
  const filePath = await telegramFilePath(fileId);
  const encodedPath = filePath
    .split("/")
    .map((segment) => encodeURIComponent(segment))
    .join("/");
  const response = await fetch(
    `${TELEGRAM_FILE_API}/bot${token}/${encodedPath}`,
    {
      headers: rangeHeader ? { Range: rangeHeader } : undefined,
    },
  ).catch(() => {
    throw new TelegramStorageError();
  });

  if (!response.ok || !response.body) {
    await response.body?.cancel().catch(() => undefined);
    throw new TelegramStorageError();
  }
  return response;
}

export async function deleteTelegramMessage(messageId: number): Promise<void> {
  const { token, chatId } = telegramConfig();
  try {
    const response = await axios.post<TelegramResult<boolean>>(
      `${TELEGRAM_API}/bot${token}/deleteMessage`,
      { chat_id: chatId, message_id: messageId },
      { timeout: 20_000 },
    );
    if (!response.data.ok || response.data.result !== true) {
      throw new TelegramStorageError();
    }
  } catch {
    throw new TelegramStorageError();
  }
}