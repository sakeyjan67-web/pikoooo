export interface RecommendationCandidate {
  id: string;
  ownerId: string;
  tags: string[];
  createdAtMs: number;
  likeCount: number;
  commentCount: number;
  shareCount: number;
  saveCount: number;
  viewCount: number;
  averageCompletionPercent: number;
}

export interface RecommendationSignalInput {
  topicWeights: Record<string, number>;
  creatorWeights: Record<string, number>;
  negativeVideoIds: Record<string, number>;
  interactionCount: number;
}

export interface RecommendationScore {
  personalization: number;
  watchQuality: number;
  engagement: number;
  freshness: number;
  exploration: number;
  final: number;
}

export interface RankedRecommendation<T extends RecommendationCandidate> {
  candidate: T;
  reason: string;
  scores: RecommendationScore;
}

function clamp01(value: number): number {
  return Math.max(0, Math.min(1, value));
}

function normalizedAffinity(weight: number | undefined): number {
  return clamp01((weight ?? 0) / 8);
}

function scoreCandidate<T extends RecommendationCandidate>(
  candidate: T,
  signals: RecommendationSignalInput,
  nowMs: number,
  coldStart: boolean,
): RecommendationScore {
  const topicValues = candidate.tags.map((tag) =>
    normalizedAffinity(signals.topicWeights[tag]),
  );
  const topicAffinity =
    topicValues.length > 0
      ? topicValues.reduce((sum, value) => sum + value, 0) / topicValues.length
      : 0;
  const creatorAffinity = normalizedAffinity(
    signals.creatorWeights[candidate.ownerId],
  );
  const personalization = clamp01(
    topicAffinity * 0.72 + creatorAffinity * 0.28,
  );

  const watchQuality = clamp01(candidate.averageCompletionPercent / 100);
  const engagement = clamp01(
    (candidate.likeCount * 2.2 +
      candidate.commentCount * 4 +
      candidate.shareCount * 4.5 +
      candidate.saveCount * 2.5) /
      (candidate.viewCount + 24),
  );
  const ageHours = Math.max(0, (nowMs - candidate.createdAtMs) / 3_600_000);
  const freshness = clamp01(Math.exp(-ageHours / 72));
  const exploration = clamp01(
    (1 - creatorAffinity) * 0.6 + (1 - topicAffinity) * 0.4,
  );

  const weights = coldStart
    ? {
        personalization: 0.08,
        watchQuality: 0.2,
        engagement: 0.31,
        freshness: 0.25,
        exploration: 0.16,
      }
    : {
        personalization: 0.38,
        watchQuality: 0.2,
        engagement: 0.18,
        freshness: 0.14,
        exploration: 0.1,
      };

  return {
    personalization,
    watchQuality,
    engagement,
    freshness,
    exploration,
    final: clamp01(
      personalization * weights.personalization +
        watchQuality * weights.watchQuality +
        engagement * weights.engagement +
        freshness * weights.freshness +
        exploration * weights.exploration,
    ),
  };
}

function explain(scores: RecommendationScore, coldStart: boolean): string {
  if (coldStart) return "Popular, recent, and varied for a new account";
  if (scores.personalization >= 0.62) return "Matches topics you have engaged with";
  if (scores.engagement >= 0.72) return "Popular with viewers";
  if (scores.freshness >= 0.78) return "Recently uploaded";
  if (scores.exploration >= 0.72) return "A new creator or topic to explore";
  return "Selected from your watch and interaction signals";
}

export function rankRecommendations<T extends RecommendationCandidate>(
  candidates: T[],
  signals: RecommendationSignalInput,
  recentlyServedIds: Set<string>,
  limit: number,
  nowMs = Date.now(),
): RankedRecommendation<T>[] {
  const coldStart = signals.interactionCount < 3;
  const negativeCutoff = nowMs - 7 * 24 * 60 * 60 * 1000;
  const scored = candidates
    .filter((candidate) => !recentlyServedIds.has(candidate.id))
    .filter(
      (candidate) =>
        (signals.negativeVideoIds[candidate.id] ?? 0) < negativeCutoff,
    )
    .map((candidate) => {
      const scores = scoreCandidate(candidate, signals, nowMs, coldStart);
      return {
        candidate,
        scores,
        reason: explain(scores, coldStart),
      };
    });

  const remaining = [...scored];
  const output: RankedRecommendation<T>[] = [];
  const creatorCounts = new Map<string, number>();
  const topicCounts = new Map<string, number>();

  while (remaining.length > 0 && output.length < limit) {
    let bestIndex = -1;
    let bestAdjusted = Number.NEGATIVE_INFINITY;

    for (let index = 0; index < remaining.length; index += 1) {
      const item = remaining[index];
      const creatorCount = creatorCounts.get(item.candidate.ownerId) ?? 0;
      const primaryTag = item.candidate.tags[0] ?? "untagged";
      const topicCount = topicCounts.get(primaryTag) ?? 0;
      const adjusted =
        item.scores.final -
        Math.max(0, creatorCount - 1) * 0.12 -
        Math.max(0, topicCount - 2) * 0.08;
      if (adjusted > bestAdjusted) {
        bestAdjusted = adjusted;
        bestIndex = index;
      }
    }

    if (bestIndex < 0) break;
    const [selected] = remaining.splice(bestIndex, 1);
    output.push(selected);
    creatorCounts.set(
      selected.candidate.ownerId,
      (creatorCounts.get(selected.candidate.ownerId) ?? 0) + 1,
    );
    const primaryTag = selected.candidate.tags[0] ?? "untagged";
    topicCounts.set(primaryTag, (topicCounts.get(primaryTag) ?? 0) + 1);
  }

  return output;
}