import { Timestamp } from "firebase-admin/firestore";
import type { Transaction } from "firebase-admin/firestore";
import { firestore } from "./firebase";

export type SignalKind =
  | "watch"
  | "skip"
  | "share"
  | "like"
  | "unlike"
  | "save"
  | "unsave"
  | "comment"
  | "follow"
  | "unfollow";

export interface RecommendationSignalProfile {
  topicWeights: Record<string, number>;
  creatorWeights: Record<string, number>;
  negativeVideoIds: Record<string, number>;
  interactionCount: number;
  updatedAt: Timestamp;
}

export interface SignalUpdate {
  kind: SignalKind;
  videoId?: string;
  ownerId?: string;
  tags?: string[];
  completionPercent?: number;
  occurredAtMs: number;
}

export async function applySignalInTransaction(
  transaction: Transaction,
  uid: string,
  eventId: string,
  update: SignalUpdate,
): Promise<boolean> {
  const userRef = firestore.collection("users").doc(uid);
  const signalRef = userRef.collection("recommendationSignals").doc("profile");
  const eventRef = userRef.collection("videoEvents").doc(eventId);
  const [eventSnapshot, signalSnapshot] = await Promise.all([
    transaction.get(eventRef),
    transaction.get(signalRef),
  ]);

  if (eventSnapshot.exists) return false;

  const updatedSignals = updateSignalProfile(
    signalSnapshot.data() as RecommendationSignalProfile | undefined,
    update,
  );

  transaction.create(eventRef, {
    eventId,
    kind: update.kind,
    videoId: update.videoId ?? null,
    ownerId: update.ownerId ?? null,
    tags: update.tags ?? [],
    completionPercent: update.completionPercent ?? null,
    createdAt: updatedSignals.updatedAt,
  });
  transaction.set(signalRef, updatedSignals);
  return true;
}

function deltaFor(update: SignalUpdate): number {
  switch (update.kind) {
    case "watch":
      if ((update.completionPercent ?? 15) >= 80) return 1.5;
      if ((update.completionPercent ?? 15) >= 35) return 0.55;
      if ((update.completionPercent ?? 15) <= 10) return -0.4;
      return 0.15;
    case "skip":
      return -1.5;
    case "share":
      return 2.5;
    case "like":
      return 3.2;
    case "unlike":
      return -1.1;
    case "save":
      return 3.4;
    case "unsave":
      return -1;
    case "comment":
      return 1.8;
    case "follow":
      return 2;
    case "unfollow":
      return -0.8;
  }
}

function boundedMap(
  input: Record<string, number>,
  key: string | undefined,
  delta: number,
): Record<string, number> {
  if (!key) return input;
  const next = { ...input };
  const value = Math.max(-100, Math.min(100, (next[key] ?? 0) + delta));
  if (Math.abs(value) < 0.05) {
    delete next[key];
  } else {
    next[key] = value;
  }

  const entries = Object.entries(next)
    .sort((a, b) => Math.abs(b[1]) - Math.abs(a[1]))
    .slice(0, 80);
  return Object.fromEntries(entries);
}

export function updateSignalProfile(
  previous: Partial<RecommendationSignalProfile> | undefined,
  update: SignalUpdate,
): RecommendationSignalProfile {
  const delta = deltaFor(update);
  let topicWeights = previous?.topicWeights ?? {};
  for (const tag of update.tags ?? []) {
    topicWeights = boundedMap(topicWeights, tag, delta);
  }

  const creatorWeights = boundedMap(
    previous?.creatorWeights ?? {},
    update.ownerId,
    delta,
  );

  const negativeVideoIds = { ...(previous?.negativeVideoIds ?? {}) };
  if (update.videoId && update.kind === "skip") {
    negativeVideoIds[update.videoId] = update.occurredAtMs;
  } else if (update.videoId && delta > 0) {
    delete negativeVideoIds[update.videoId];
  }

  const recentNegativeEntries = Object.entries(negativeVideoIds)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 100);

  return {
    topicWeights,
    creatorWeights,
    negativeVideoIds: Object.fromEntries(recentNegativeEntries),
    interactionCount: (previous?.interactionCount ?? 0) + 1,
    updatedAt: Timestamp.fromMillis(update.occurredAtMs),
  };
}