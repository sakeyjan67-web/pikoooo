import {
  cert,
  getApps,
  initializeApp,
  type ServiceAccount,
} from "firebase-admin/app";
import { getAuth } from "firebase-admin/auth";
import { getFirestore } from "firebase-admin/firestore";

interface FirebaseServiceAccount extends ServiceAccount {
  project_id?: string;
  projectId?: string;
}

const rawServiceAccount = process.env.FIREBASE_SERVICE_ACCOUNT_JSON;

if (!rawServiceAccount) {
  throw new Error("FIREBASE_SERVICE_ACCOUNT_JSON is required.");
}

let serviceAccount: FirebaseServiceAccount;

try {
  serviceAccount = JSON.parse(rawServiceAccount) as FirebaseServiceAccount;
} catch {
  throw new Error("FIREBASE_SERVICE_ACCOUNT_JSON must contain valid JSON.");
}

const projectId =
  process.env.FIREBASE_PROJECT_ID ??
  serviceAccount.project_id ??
  serviceAccount.projectId;

if (!projectId) {
  throw new Error("Firebase service-account project ID is missing.");
}

const appName = "camtok-api";
const firebaseApp =
  getApps().find((app) => app.name === appName) ??
  initializeApp(
    {
      credential: cert(serviceAccount),
      projectId,
    },
    appName,
  );

export const firebaseAuth = getAuth(firebaseApp);
export const firestore = getFirestore(firebaseApp);