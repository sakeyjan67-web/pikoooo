import type { UserProfile, VideoRecord } from "./models";

export function canViewVideo(
  viewerUid: string,
  video: VideoRecord,
  owner: UserProfile,
  isFollower: boolean,
): boolean {
  if (
    video.status !== "ready" ||
    (owner.accountStatus ?? "active") !== "active"
  ) {
    return false;
  }
  if (video.ownerId === viewerUid) return true;
  if (video.visibility === "private") return false;
  if (video.visibility === "followers" || owner.isPrivate) return isFollower;
  return video.visibility === "public";
}