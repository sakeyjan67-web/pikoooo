import type { DocumentReference } from "firebase-admin/firestore";
import { firestore } from "./firebase";
import { isSafeDocumentId, type UserProfile, type VideoRecord } from "./models";
import { canViewVideo } from "./video-visibility";

export interface AccessibleVideo {
  ref: DocumentReference;
  video: VideoRecord;
}

export async function findAccessibleVideo(
  viewerUid: string,
  videoId: string,
): Promise<AccessibleVideo | null> {
  if (!isSafeDocumentId(videoId)) return null;
  const videoRef = firestore.collection("videos").doc(videoId);
  const videoSnapshot = await videoRef.get();
  if (!videoSnapshot.exists) return null;

  const video = videoSnapshot.data() as VideoRecord;
  if (video.status !== "ready") return null;
  if (video.ownerId === viewerUid) return { ref: videoRef, video };

  const ownerSnapshot = await firestore
    .collection("users")
    .doc(video.ownerId)
    .get();
  if (!ownerSnapshot.exists) return null;

  const owner = ownerSnapshot.data() as UserProfile;
  const requiresFollow =
    video.visibility === "followers" || owner.isPrivate === true;
  const isFollower = requiresFollow
    ? (
        await firestore
          .collection("users")
          .doc(viewerUid)
          .collection("following")
          .doc(video.ownerId)
          .get()
      ).exists
    : false;
  if (!canViewVideo(viewerUid, video, owner, isFollower)) return null;
  return { ref: videoRef, video };
}