import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path, PurePosixPath
from urllib.parse import quote

import requests


PROJECT_DIR = Path(__file__).resolve().parent
UPLOAD_METADATA_PATH = PROJECT_DIR / "tmp" / "piko_telegram_upload_result_23.json"
EXPECTED_CHANNEL_TITLE = "Camtok database"
EXPECTED_MESSAGE_ID = 23
MAX_ERROR_DESCRIPTION_LENGTH = 180


def _read_json(response):
    try:
        payload = response.json()
    except ValueError:
        return None
    return payload if isinstance(payload, dict) else None


def _report_api_failure(response, payload, action, token):
    error_code = payload.get("error_code") if isinstance(payload, dict) else None
    description = payload.get("description") if isinstance(payload, dict) else None
    normalized = description.casefold() if isinstance(description, str) else ""

    if response.status_code == 401 or error_code == 401:
        print(f"Retrieval failed: Telegram rejected the bot credentials during {action}.")
    elif response.status_code == 403 or error_code == 403:
        print(f"Retrieval failed: Telegram denied access during {action}.")
    elif "wrong file identifier" in normalized or "file_id" in normalized:
        print("Retrieval failed: Telegram rejected the saved file_id as invalid or unknown.")
    elif "file is too big" in normalized:
        print("Retrieval failed: Telegram reports that the file exceeds its download limit.")
    elif isinstance(description, str) and description:
        safe_description = description.replace(token, "[redacted]")
        safe_description = " ".join(safe_description.split())
        safe_description = safe_description[:MAX_ERROR_DESCRIPTION_LENGTH]
        print(
            f"Retrieval failed during {action} "
            f"(HTTP {response.status_code}, API {error_code or 'unknown'}): "
            f"{safe_description}"
        )
    else:
        print(
            f"Retrieval failed during {action} "
            f"(HTTP {response.status_code}; Telegram returned no usable error detail)."
        )


def _sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as file_obj:
        for chunk in iter(lambda: file_obj.read(64 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _download_path(message_id):
    result_dir = PROJECT_DIR / "tmp"
    result_dir.mkdir(parents=True, exist_ok=True)
    base_path = result_dir / f"piko_telegram_retrieved_test_{message_id}.mp4"
    candidate = base_path
    suffix = 1
    while candidate.exists():
        candidate = result_dir / f"piko_telegram_retrieved_test_{message_id}_{suffix}.mp4"
        suffix += 1
    return candidate


def _probe_video(path):
    try:
        completed = subprocess.run(
            [
                "ffprobe",
                "-v",
                "error",
                "-select_streams",
                "v:0",
                "-show_entries",
                "stream=codec_name,codec_type,width,height",
                "-show_entries",
                "format=format_name,duration,size",
                "-of",
                "json",
                str(path),
            ],
            check=True,
            capture_output=True,
            text=True,
            timeout=20,
        )
        probe = json.loads(completed.stdout)
    except (
        FileNotFoundError,
        subprocess.CalledProcessError,
        subprocess.TimeoutExpired,
        ValueError,
    ):
        return None

    streams = probe.get("streams")
    format_info = probe.get("format")
    if not isinstance(streams, list) or not isinstance(format_info, dict):
        return None

    video_stream = next(
        (
            stream
            for stream in streams
            if isinstance(stream, dict) and stream.get("codec_type") == "video"
        ),
        None,
    )
    format_names = format_info.get("format_name", "")
    if (
        not isinstance(video_stream, dict)
        or not isinstance(format_names, str)
        or "mp4" not in format_names.casefold()
    ):
        return None

    return video_stream, format_info


def retrieve_test_video():
    token = os.environ.get("TELEGRAM_BOT_TOKEN")
    if not token:
        print("Retrieval failed: Telegram bot credentials are not configured.")
        return False

    try:
        metadata = json.loads(UPLOAD_METADATA_PATH.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        print("Retrieval failed: the saved Setup 4 upload metadata file is missing or invalid.")
        return False

    if (
        not isinstance(metadata, dict)
        or metadata.get("channel_title") != EXPECTED_CHANNEL_TITLE
        or metadata.get("message_id") != EXPECTED_MESSAGE_ID
        or not isinstance(metadata.get("file_id"), str)
        or not metadata["file_id"]
    ):
        print("Retrieval failed: the saved metadata does not identify the Setup 4 test upload.")
        return False

    relative_source = metadata.get("test_video")
    if not isinstance(relative_source, str):
        print("Retrieval failed: the Setup 4 source video path is missing from its metadata.")
        return False

    source_video = (PROJECT_DIR / relative_source).resolve()
    try:
        source_video.relative_to(PROJECT_DIR.resolve())
    except ValueError:
        print("Retrieval failed: the saved source video path is outside the project.")
        return False

    if not source_video.is_file():
        print("Retrieval failed: the original Setup 4 test video is unavailable for comparison.")
        return False

    api_base = f"https://api.telegram.org/bot{token}"
    try:
        get_file_response = requests.get(
            f"{api_base}/getFile",
            params={"file_id": metadata["file_id"]},
            timeout=20,
            allow_redirects=False,
        )
    except requests.RequestException:
        print("Retrieval failed: Telegram getFile could not be reached.")
        return False

    get_file_payload = _read_json(get_file_response)
    if (
        get_file_payload is None
        or get_file_response.status_code != 200
        or get_file_payload.get("ok") is not True
    ):
        _report_api_failure(get_file_response, get_file_payload, "getFile", token)
        return False

    file_info = get_file_payload.get("result")
    remote_path = file_info.get("file_path") if isinstance(file_info, dict) else None
    if not isinstance(remote_path, str) or not remote_path:
        print("Retrieval failed: Telegram getFile returned no file path.")
        return False

    parsed_path = PurePosixPath(remote_path)
    if parsed_path.is_absolute() or ".." in parsed_path.parts:
        print("Retrieval failed: Telegram returned an unsafe file path.")
        return False

    reported_size = file_info.get("file_size") if isinstance(file_info, dict) else None
    encoded_path = quote(remote_path, safe="/")
    download_url = f"https://api.telegram.org/file/bot{token}/{encoded_path}"
    destination = _download_path(EXPECTED_MESSAGE_ID)

    try:
        download_response = requests.get(
            download_url,
            stream=True,
            timeout=(15, 60),
            allow_redirects=False,
        )
    except requests.RequestException:
        print("Retrieval failed: Telegram's file download endpoint could not be reached.")
        return False

    try:
        if download_response.status_code != 200:
            _report_api_failure(
                download_response,
                _read_json(download_response),
                "file download",
                token,
            )
            return False

        try:
            with destination.open("xb") as downloaded_file:
                for chunk in download_response.iter_content(chunk_size=64 * 1024):
                    if chunk:
                        downloaded_file.write(chunk)
        except (OSError, requests.RequestException):
            print("Retrieval failed: the downloaded video could not be saved completely.")
            return False
    finally:
        download_response.close()

    downloaded_size = destination.stat().st_size
    if downloaded_size <= 0:
        print(f"Retrieval failed: Telegram returned an empty file at {destination.relative_to(PROJECT_DIR)}.")
        return False

    if isinstance(reported_size, int) and reported_size != downloaded_size:
        print(
            "Retrieval failed: downloaded size does not match Telegram's getFile metadata "
            f"({downloaded_size} bytes received; {reported_size} bytes reported)."
        )
        return False

    expected_size = metadata.get("file_size")
    if isinstance(expected_size, int) and expected_size != downloaded_size:
        print(
            "Retrieval failed: downloaded size does not match the Setup 4 upload record "
            f"({downloaded_size} bytes received; {expected_size} bytes recorded)."
        )
        return False

    if destination.read_bytes()[4:8] != b"ftyp":
        print("Retrieval failed: the downloaded bytes do not have an MP4 file signature.")
        return False

    probe_result = _probe_video(destination)
    if probe_result is None:
        print("Retrieval failed: the downloaded file is not a readable MP4 video.")
        return False

    video_stream, format_info = probe_result
    source_digest = _sha256(source_video)
    downloaded_digest = _sha256(destination)
    if source_digest != downloaded_digest:
        print(
            "Retrieval failed: Telegram returned an MP4 video, but its bytes differ "
            "from the Setup 4 test upload."
        )
        return False

    content_type = download_response.headers.get("Content-Type", "").split(";", 1)[0].strip()
    codec = video_stream.get("codec_name", "unknown")
    width = video_stream.get("width", "unknown")
    height = video_stream.get("height", "unknown")
    duration = format_info.get("duration", "unknown")
    print("Retrieval PASS")
    print("Function: retrieve_test_video()")
    print("Method: Telegram getFile followed by the official file download endpoint")
    print("Telegram returned the stored video; its SHA-256 matches the Setup 4 source.")
    print(f"File size: {downloaded_size} bytes")
    print(
        f"File type: video/mp4 ({codec}, {width}x{height}, "
        f"{duration} seconds; response Content-Type: {content_type or 'not provided'})"
    )
    print(f"Retrieved copy: {destination.relative_to(PROJECT_DIR).as_posix()}")
    return True


if __name__ == "__main__":
    sys.exit(0 if retrieve_test_video() else 1)