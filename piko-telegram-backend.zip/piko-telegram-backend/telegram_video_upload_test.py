import json
import os
import subprocess
import sys
from pathlib import Path

import requests


PROJECT_DIR = Path(__file__).resolve().parent
TEST_VIDEO_PATH = PROJECT_DIR / "tmp" / "piko_telegram_upload_test.mp4"
EXPECTED_CHANNEL_TITLE = "Camtok database"
MAX_TEST_VIDEO_SIZE = 5 * 1024 * 1024


def _ensure_test_video():
    if TEST_VIDEO_PATH.exists():
        return TEST_VIDEO_PATH.is_file() and TEST_VIDEO_PATH.stat().st_size > 0

    TEST_VIDEO_PATH.parent.mkdir(parents=True, exist_ok=True)
    command = [
        "ffmpeg",
        "-nostdin",
        "-hide_banner",
        "-loglevel",
        "error",
        "-f",
        "lavfi",
        "-i",
        "testsrc=size=160x120:rate=2:duration=2",
        "-frames:v",
        "4",
        "-an",
        "-c:v",
        "libx264",
        "-preset",
        "ultrafast",
        "-crf",
        "36",
        "-pix_fmt",
        "yuv420p",
        "-movflags",
        "+faststart",
        str(TEST_VIDEO_PATH),
    ]

    try:
        subprocess.run(
            command,
            check=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    except (FileNotFoundError, subprocess.CalledProcessError):
        return False

    return TEST_VIDEO_PATH.is_file() and TEST_VIDEO_PATH.stat().st_size > 0


def _api_failure(response, payload, action):
    error_code = payload.get("error_code") if isinstance(payload, dict) else None
    description = payload.get("description") if isinstance(payload, dict) else None

    if response.status_code == 401 or error_code == 401:
        print("Telegram rejected the bot credentials.")
    elif response.status_code == 403 or error_code == 403:
        print("The bot does not have permission to access the storage channel.")
    elif isinstance(description, str) and "chat not found" in description.casefold():
        print("Telegram could not find the configured storage channel.")
    elif response.status_code == 413 or error_code == 413:
        print("Telegram rejected the test video as too large.")
    else:
        print(f"Telegram {action} failed.")


def _parse_response(response):
    try:
        payload = response.json()
    except ValueError:
        return None

    if (
        response.status_code != 200
        or not isinstance(payload, dict)
        or payload.get("ok") is not True
    ):
        return payload

    return payload


def _save_metadata(metadata, message_id):
    result_dir = PROJECT_DIR / "tmp"
    result_dir.mkdir(parents=True, exist_ok=True)
    base_path = result_dir / f"piko_telegram_upload_result_{message_id}.json"
    result_path = base_path
    suffix = 1
    while result_path.exists():
        result_path = result_dir / f"piko_telegram_upload_result_{message_id}_{suffix}.json"
        suffix += 1

    try:
        with result_path.open("x", encoding="utf-8") as result_file:
            json.dump(metadata, result_file, ensure_ascii=False, indent=2)
            result_file.write("\n")
    except OSError:
        return None

    return result_path


def main():
    token = os.environ.get("TELEGRAM_BOT_TOKEN")
    chat_id = os.environ.get("TELEGRAM_STORAGE_CHAT_ID")

    if not token or not chat_id:
        print("Upload failed: required Telegram configuration is missing.")
        return False

    if not _ensure_test_video():
        print("Upload failed: the tiny test video could not be prepared.")
        return False

    local_file_size = TEST_VIDEO_PATH.stat().st_size
    if local_file_size > MAX_TEST_VIDEO_SIZE:
        print("Upload failed: the test video exceeds the small-test size limit.")
        return False

    api_base = f"https://api.telegram.org/bot{token}"

    try:
        chat_response = requests.get(
            f"{api_base}/getChat",
            params={"chat_id": chat_id.strip()},
            timeout=15,
            allow_redirects=False,
        )
        chat_payload = _parse_response(chat_response)
        if (
            chat_payload is None
            or chat_response.status_code != 200
            or not isinstance(chat_payload, dict)
            or chat_payload.get("ok") is not True
        ):
            _api_failure(chat_response, chat_payload, "storage-channel check")
            return False

        chat = chat_payload.get("result")
        if (
            not isinstance(chat, dict)
            or chat.get("type") != "channel"
            or chat.get("title") != EXPECTED_CHANNEL_TITLE
        ):
            print("Upload stopped: the configured destination is not the expected storage channel.")
            return False

        with TEST_VIDEO_PATH.open("rb") as video_file:
            upload_response = requests.post(
                f"{api_base}/sendVideo",
                data={
                    "chat_id": chat_id.strip(),
                    "caption": "PIKO controlled small test upload — not production media",
                },
                files={
                    "video": (
                        TEST_VIDEO_PATH.name,
                        video_file,
                        "video/mp4",
                    )
                },
                timeout=(15, 60),
                allow_redirects=False,
            )

        upload_payload = _parse_response(upload_response)
        if (
            upload_payload is None
            or upload_response.status_code != 200
            or not isinstance(upload_payload, dict)
            or upload_payload.get("ok") is not True
        ):
            _api_failure(upload_response, upload_payload, "video upload")
            return False
    except requests.RequestException:
        print("Upload failed: Telegram could not be reached.")
        return False

    message = upload_payload.get("result")
    video = message.get("video") if isinstance(message, dict) else None
    message_id = message.get("message_id") if isinstance(message, dict) else None
    file_id = video.get("file_id") if isinstance(video, dict) else None

    if not isinstance(message_id, int) or not isinstance(file_id, str) or not file_id:
        print("Telegram accepted the request but returned incomplete upload metadata.")
        return False

    returned_file_size = video.get("file_size") if isinstance(video, dict) else None
    file_size = (
        returned_file_size
        if isinstance(returned_file_size, int) and returned_file_size > 0
        else local_file_size
    )
    mime_type = video.get("mime_type") if isinstance(video, dict) else None
    if not isinstance(mime_type, str) or not mime_type:
        mime_type = "video/mp4"

    metadata = {
        "channel_title": EXPECTED_CHANNEL_TITLE,
        "message_id": message_id,
        "file_id": file_id,
        "file_unique_id": video.get("file_unique_id"),
        "file_size": file_size,
        "mime_type": mime_type,
        "width": video.get("width"),
        "height": video.get("height"),
        "duration_seconds": video.get("duration"),
        "test_video": TEST_VIDEO_PATH.relative_to(PROJECT_DIR).as_posix(),
    }
    metadata_path = _save_metadata(metadata, message_id)

    print("Upload PASS")
    print(f"Channel: {EXPECTED_CHANNEL_TITLE}")
    print(f"Message ID: {message_id}")
    print(f"Telegram file ID: {file_id}")
    print(f"File size: {file_size} bytes")
    print(f"File type: {mime_type}")
    if metadata_path:
        print(f"Metadata saved: {metadata_path.relative_to(PROJECT_DIR).as_posix()}")
    else:
        print("Metadata note: upload succeeded, but the local metadata file could not be saved.")

    return True


if __name__ == "__main__":
    sys.exit(0 if main() else 1)