import os

import requests


def main():
    token = os.environ.get("TELEGRAM_BOT_TOKEN")
    if not token:
        print("Telegram bot connection failed.")
        return

    url = f"https://api.telegram.org/bot{token}/getMe"

    try:
        response = requests.get(url, timeout=15, allow_redirects=False)
        if response.status_code != 200:
            print("Telegram bot connection failed.")
            return

        try:
            payload = response.json()
        except ValueError:
            print("Telegram bot connection failed.")
            return

        if not isinstance(payload, dict) or payload.get("ok") is not True:
            print("Telegram bot connection failed.")
            return

        result = payload.get("result")
        username = result.get("username") if isinstance(result, dict) else None
        if not isinstance(username, str) or not username.strip():
            print("Telegram bot connection failed.")
            return

        print("Telegram bot connected successfully!")
        print(f"Bot username: {username}")
    except requests.RequestException:
        print("Telegram bot connection failed.")


if __name__ == "__main__":
    main()