---
name: Camtok storage boundaries
description: Camtok's user data, video media, and retained PostgreSQL scaffold.
---

Camtok's runtime application data belongs in Firebase Firestore. MP4 media belongs in the private Telegram channel titled “Camtok database”. Preserve the PostgreSQL scaffold; do not migrate to it, remove it, or write application data to it.

**Why:** the user specified Firebase for application data, Telegram for video storage, and explicitly asked to preserve the existing PostgreSQL setup without using it.

**How to apply:** Keep profile, video metadata, interactions, and recommendation signals in Firestore; keep video files in Telegram; leave PostgreSQL schema and data untouched.