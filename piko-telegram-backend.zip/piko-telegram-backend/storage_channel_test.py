import os

import requests


def _report_api_failure(response, payload):
    error_code = payload.get("error_code") if isinstance(payload, dict) else None
    description = payload.get("description") if isinstance(payload, dict) else None
    status_code = response.status_code

    if status_code == 401 or error_code == 401:
        print("Telegram rejected the bot token.")
    elif status_code == 403 or error_code == 403:
        print("The bot does not have access to the storage channel.")
    elif isinstance(description, str) and "chat not found" in description.casefold():
        print(
            "Telegram could not find the storage channel. Check "
            "TELEGRAM_STORAGE_CHAT_ID and confirm the bot is a channel member."
        )
    elif status_code == 400 or error_code == 400:
        print("Telegram rejected the storage channel request. Check the channel ID.")
    else:
        print("Telegram storage channel check failed.")


def verify_storage_channel():
    token = os.environ.get("TELEGRAM_BOT_TOKEN")
    chat_id = os.environ.get("TELEGRAM_STORAGE_CHAT_ID")

    if not chat_id:
        print("TELEGRAM_STORAGE_CHAT_ID is not configured.")
        return False

    if not token:
        print("Telegram storage channel check failed.")
        return False

    url = f"https://api.telegram.org/bot{token}/getChat"

    try:
        response = requests.get(
            url,
            params={"chat_id": chat_id.strip()},
            timeout=15,
            allow_redirects=False,
        )

        try:
            payload = response.json()
        except ValueError:
            print("Telegram storage channel check failed.")
            return False

        if (
            response.status_code != 200
            or not isinstance(payload, dict)
            or payload.get("ok") is not True
        ):
            _report_api_failure(response, payload)
            return False

        chat = payload.get("result")
        title = chat.get("title") if isinstance(chat, dict) else None
        if not isinstance(title, str) or not title.strip():
            print("Telegram storage channel check failed.")
            return False

        print("Telegram bot can access the storage channel.")
        print(f"Channel title: {title}")
        return True
    except requests.RequestException:
        print("Telegram storage channel check failed.")
        return False


if __name__ == "__main__":
    verify_storage_channel()